# Moja stranica

Ovo je jednostavna GitHub Pages stranica koja koristi Jekyll i temu **minima**.

## Kako pokrenuti lokalno
1. Instaliraj [Jekyll](https://jekyllrb.com/).
2. Pokreni:
   ```bash
   bundle exec jekyll serve
   ```
3. Otvori [http://localhost:4000](http://localhost:4000).

## Live verzija
[https://tvoje-korisnicko-ime.github.io/moja-stranica/](https://tvoje-korisnicko-ime.github.io/moja-stranica/)
